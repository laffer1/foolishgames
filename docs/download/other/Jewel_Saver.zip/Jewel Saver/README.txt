JewelSaver:  A Jewel screen saver for Windows

Written by Lucas Holt
http://www.foolishgames.com/

Version 1.0 Alpha

System Requirements:

Tested on Windows XP home edition, should work with
Windows 2000, Windows ME, and Windows 98 SE.

Requires .NET framework 1.1 which can be obtained
from Windows Update or http://msdn.microsoft.com/

Release Notes:

This is an Alpha release.  It does not center the
images, and has no configuration options.  Preview
does not work in the Display Properites window.

Please report bugs using the email form on my
website. http://www.foolishgames.com/email/

Bugs fixed:

1.0 Alpha
Memory leak in bitmap image code.  Caused large
amounts of ram to be consumed in a short time.

1.0 Pre Alpha
Initial release
